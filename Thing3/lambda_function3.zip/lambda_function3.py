import json
import requests
def lambda_handler(event, context):
	# TODO implement
	url_str = "http://40.71.37.116:8443/quality/"
	headers = {'Content-type': 'application/json'}
	response = requests.post(url = url_str, data = json.dumps(event), headers=headers)
	return response.json()
