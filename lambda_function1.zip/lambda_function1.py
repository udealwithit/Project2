import json
import requests
def lambda_handler(event, context):
	# TODO implement
	url_str = "https://52.149.143.178:8443/collect/quality"
	response = requests.post(url = url_str, data = event)
	return {
		"statusCode": 200,
		"event": json.dumps(event),
		"body": json.dumps(response)
	}
