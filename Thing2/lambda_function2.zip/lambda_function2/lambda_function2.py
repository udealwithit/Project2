import json
import requests
def lambda_handler(event, context):
	# TODO implement
	url_str = "http://13.82.133.230:8443/collect/quality"
	headers = {'Content-type': 'application/json','Accept': 'text/plain'}
	response = requests.post(url = url_str, data = json.dumps(event), headers=headers)
	return response.json()
